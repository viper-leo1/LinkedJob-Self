import { Component, OnInit } from '@angular/core';
import { Jobs } from '../../model/Jobs';
import { JobsDataService } from '../../Services/jobs-data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'job-detail',
  templateUrl: './job-detail.component.html',
  styleUrl: './job-detail.component.css'
})
export class JobDetailComponent implements OnInit{

  id:string='';
  detailedView:Jobs[]=[];

  constructor(private jobsDataService:JobsDataService , 
              private router:ActivatedRoute){}

  ngOnInit(){
    this.router.params.subscribe((param)=>{
      this.id=param['id']
      this.jobsDataService.ViewMore(this.id).subscribe((data)=>{
        this.detailedView = data;
        // console.log(data)
        // console.log(this.detailedView)
      })

    })

  }


}
