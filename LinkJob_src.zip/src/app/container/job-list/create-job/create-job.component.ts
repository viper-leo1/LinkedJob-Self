import { Component } from '@angular/core';

@Component({
  selector: 'create-job',
  templateUrl: './create-job.component.html',
  styleUrl: './create-job.component.css'
})
export class CreateJobComponent {

}
