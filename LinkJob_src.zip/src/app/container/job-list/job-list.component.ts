import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { JobsDataService } from '../../Services/jobs-data.service';
import { Jobs } from '../../model/Jobs';

@Component({
  selector: 'job-list',
  templateUrl: './job-list.component.html',
  styleUrl: './job-list.component.css'
})
export class JobListComponent implements OnInit {

  //property to add the data
  jobs: Jobs[] = [];

  isEditMode: boolean = false;

  currentId: string = '';

  //declaration to form a formGroup that is created in the view template by reference
  reactiveForm: FormGroup;


  constructor(private fb: FormBuilder,
    private jobsDataService: JobsDataService) { }

  ngOnInit() {
    this.reactiveForm = this.fb.group({
      title: [null, [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/)]],
      company: [null, [Validators.required, Validators.pattern(/^[a-zA-Z0-9 ]*$/)]],
      location: [null, [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/)]],
      description: [null, [Validators.required]],
      category: [null, [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/)]],
      qualification: [null, [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/)]],
      salary: [null, [Validators.required, Validators.pattern(/^[a-zA-Z0-9 ]*$/)]],

    });

    this.fetchJob();
  }

  // OnFormSubmitted() {
  //   this.jobs = this.reactiveForm.value;
  //   console.log('jobs=> ', this.jobs);

  // }

  //post the job
  onJobPost(jobs: {
    title: string;
    company: string;
    location: string;
    description: string;
    category: string;
    qualification: string;
    salary: string;
  }) {
    if (!this.isEditMode) {
      this.jobsDataService.postJob(jobs).subscribe(res => {
        console.log(res);
        this.reactiveForm.reset();
        this.onFetchJobs();
      })
      

    }
    else {
      this.jobsDataService.updateJob(this.currentId, jobs).subscribe(() => {
        this.isEditMode = false;
        this.reactiveForm.reset();

        this.onFetchJobs();
      })


    }
  }


  //get the job
  onFetchJobs() {
    this.fetchJob();
  }

  private fetchJob() {
    this.jobsDataService.getJobs().subscribe(data => {
      // console.log('yahi toh hai tumhara job',data)
      this.jobs = data;

      // console.log('jobs lele: ',this.jobs)
    });
  }

  


  //update the job


  // onUpdateJob(id,jobs){
  //   this.jobsDataService.updateJob(id,jobs).subscribe()
  // }

  editForm(id: string) {
    //get the selected job to edit
    this.currentId = id;
    let currentjob = this.jobs.find((p) => { return p.id === id })
    console.log('current job hai ye toh ', currentjob);

    //populate the form on the selected job
    this.reactiveForm.setValue({
      title: currentjob.title,
      company: currentjob.company,
      location: currentjob.location,
      description: currentjob.description,
      category: currentjob.category,
      qualification: currentjob.qualification,
      salary: currentjob.salary,
    }
    )


    //change the edit mode into true
    this.isEditMode = true;

  }

  //delete the job
  onDeleteJob(id: string) {
    this.currentId = id;
    this.jobsDataService.deleteJob(id).subscribe(()=>{
      this.onFetchJobs();
    });
    
  }


  //delete all the job
  onDeleteAllJob() {
    this.jobsDataService.deleteAllJob().subscribe(()=>{
      this.onFetchJobs();
    });
  }


  // Get job by their id
  // onViewMore(id){
  //   this.jobsDataService.ViewMore(id).subscribe();
  // }

}
