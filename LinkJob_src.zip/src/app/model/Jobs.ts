export class Jobs {
    title: string;
    company: string;
    location: string;
    description: string;
    category: string;
    qualification: string;
    salary: string;
    id?:string;
}