import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthResponse } from '../authInterface/auth-response';
import { BehaviorSubject, Subject, catchError, tap } from 'rxjs';
import { ErrorService } from './error.service';
import { AuthUser } from '../model/auths';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  user =new BehaviorSubject<AuthUser>(null);

  tokenExpirationTimer:any;

  ApiUrl= 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=';
  ApiKey= 'AIzaSyDtu7WiqToAvzFagtO9BaT3T6FjoryMYk4';

  constructor(private http:HttpClient,
              private _errorService:ErrorService,
              private router:Router) { }

  ngOnInit(){
    this.autoSignIn();
  }

  signUp(email, password){
    return this.http.post<AuthResponse>(`${this.ApiUrl}${this.ApiKey}`,{
      email:email,
      password:password,
      returnSecureToken:true 
    }).pipe(
      catchError((err)=>{
        return this._errorService.handleError(err);
      }),
      tap((res:AuthResponse)=>{
        console.log('hello');
        this.authenticatedUser(res.email, res.localId, res.idToken , +res.expiresIn)
      })
      )
  }

  signIn(email, password){
    return this.http.post<AuthResponse>(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${this.ApiKey}`,{
      email:email,
      password:password,
    }).pipe(
      catchError((err)=>{
        console.log('authservice',err);
        return this._errorService.handleError(err);
      }),
      tap((res:AuthResponse)=>{
        console.log('hello');
        this.authenticatedUser(res.email, res.localId, res.idToken , +res.expiresIn)
      })
      )
  }

  autoSignIn(){
    const userData= JSON.parse(localStorage.getItem('Userdata'))
    if(!userData){
      return
    }
    const loggedInUser = new AuthUser(userData.email,userData.id , userData._token , new Date(userData._tokenExpirationDate))
    if(loggedInUser.token){
      this.user.next(loggedInUser);

      const expirationduration = new Date(userData._tokenExpirationDate).getTime() - new Date().getTime();
      this.autoSignOut(expirationduration);
    }


  }

  signOut(){
    this.user.next(null)
    this.router.navigate([''])

    localStorage.removeItem('Userdata')

    if(this.tokenExpirationTimer){
      clearTimeout(this.tokenExpirationTimer);
    }
    this.tokenExpirationTimer = null;
  }

  autoSignOut(expirationDuration){
    this.tokenExpirationTimer = setTimeout(()=>{
      this.signOut();
    },expirationDuration)

  }



  private authenticatedUser(email:string,id,token,expiresIn){
    const expires = new Date(new Date().getTime() + expiresIn*1000);
    const user = new AuthUser(email,id,token,expires);
    this.user.next(user);

    console.log('authenticated user : hello')

    this.autoSignOut(expiresIn*1000)

    localStorage.setItem('Userdata',JSON.stringify(user))
  }
}
